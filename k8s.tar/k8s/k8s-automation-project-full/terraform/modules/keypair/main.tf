resource "tls_private_key" "k8s_key" {
  algorithm = "RSA"
  rsa_bits  = 4096
}

resource "local_file" "private_key" {
  content         = tls_private_key.k8s_key.private_key_pem
  filename        = "${path.module}/k8s-key.pem"
  file_permission = "0400"
}

resource "aws_key_pair" "generated_key" {
  key_name   = "k8s-common-key"
  public_key = tls_private_key.k8s_key.public_key_openssh
}
