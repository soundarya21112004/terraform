resource "aws_instance" "master" {
  ami                    = "ami-0f58b397bc5c1f2e8"
  instance_type          = "t2.medium"
  subnet_id              = var.subnet_id
  vpc_security_group_ids = [var.security_group_id]
  key_name               = var.key_name

  tags = {
    Name = "k8s-master"
    Role = "master"
  }
}

resource "aws_instance" "worker" {
  ami                    = "ami-0f58b397bc5c1f2e8"
  instance_type          = "t2.medium"
  subnet_id              = var.subnet_id
  vpc_security_group_ids = [var.security_group_id]
  key_name               = var.key_name

  tags = {
    Name = "k8s-worker"
    Role = "worker"
  }
}
